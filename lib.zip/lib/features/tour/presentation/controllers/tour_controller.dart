import 'package:get/get.dart';

import 'package:ecoach_pro/features/tour/data/tour_demo_data.dart';
import 'package:ecoach_pro/features/tour/domain/entities/tour_video.dart';

/// "Take The Tour": a list of intro videos, one selected at a time.
class TourController extends GetxController {
  // Swap for an API call later; the page only reads [videos].
  final RxList<TourVideo> videos = TourDemoData.videos.toList().obs;
  final RxInt selectedIndex = 0.obs;

  TourVideo get selected => videos[selectedIndex.value];

  void select(int index) {
    if (index < 0 || index >= videos.length) return;
    selectedIndex.value = index;
  }
}
