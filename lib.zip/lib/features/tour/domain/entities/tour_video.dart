import 'package:flutter/foundation.dart';

/// One "Take the tour" video.
@immutable
class TourVideo {
  const TourVideo({
    required this.id,
    required this.title,
    required this.description,
    required this.videoUrl,
    required this.posterAsset,
  });

  final int id;
  final String title;
  final String description;
  final String videoUrl;

  /// Local image used as the poster and as the thumbnail in the strip.
  final String posterAsset;
}
