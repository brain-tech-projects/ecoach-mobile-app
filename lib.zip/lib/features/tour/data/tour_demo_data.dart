import 'package:ecoach_pro/core/constants/app_assets.dart';
import 'package:ecoach_pro/features/tour/domain/entities/tour_video.dart';

/// DEMO DATA - replace with the API response later (same [TourVideo] shape).
abstract final class TourDemoData {
  static const String intro =
      'Watch quick videos to understand how training, skills, and progress '
      'tracking work inside the eCoach app.';

  static const List<TourVideo> videos = <TourVideo>[
    TourVideo(
      id: 1,
      title: 'Start your eCoach Pro',
      description:
          'At eCoach we offer a range of flexible plans to make sure the most '
          'children possible can benefit from the coaching and training while '
          'improving their fitness and ultimately having fun.',
      videoUrl:
          'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
      posterAsset: AppAssets.programEcoach,
    ),
    TourVideo(
      id: 2,
      title: 'Train anywhere, anytime',
      description:
          'Follow guided drills, add your favourites to a personal training '
          'session and track every match to see your rating grow.',
      videoUrl:
          'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
      posterAsset: AppAssets.programWhatsNew,
    ),
  ];
}
