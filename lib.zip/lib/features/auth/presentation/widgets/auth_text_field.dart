import 'package:flutter/material.dart';

import 'package:ecoach_pro/core/theme/app_colors.dart';
import 'package:ecoach_pro/core/theme/app_text_styles.dart';
import 'package:ecoach_pro/core/widgets/app_asset_icon.dart';

/// Rounded input with a leading icon and an optional trailing widget
/// (e.g. the show/hide-password toggle).
class AuthTextField extends StatelessWidget {
  const AuthTextField({
    super.key,
    required this.controller,
    required this.hint,
    required this.iconAsset,
    required this.iconWidth,
    required this.iconHeight,
    this.obscureText = false,
    this.keyboardType,
    this.textInputAction,
    this.autofillHints,
    this.suffix,
    this.height = 55.3,
    this.multiline = false,
    this.borderColor = AppColors.fieldBorder,
    this.onChanged,
    this.onSubmitted,
    this.scale = 1.0,
  });

  final TextEditingController controller;
  final String hint;
  final String iconAsset;
  final double iconWidth; // design points
  final double iconHeight;
  final bool obscureText;
  final TextInputType? keyboardType;
  final TextInputAction? textInputAction;
  final Iterable<String>? autofillHints;
  final Widget? suffix;
  final double height;

  /// Multi-line message box: icon and text are top-aligned.
  final bool multiline;
  final Color borderColor;
  final ValueChanged<String>? onChanged;
  final ValueChanged<String>? onSubmitted;
  final double scale;

  @override
  Widget build(BuildContext context) {
    final s = scale;

    return Container(
      height: height * s,
      decoration: BoxDecoration(
        color: AppColors.fieldFill,
        border: Border.all(color: borderColor),
        borderRadius: BorderRadius.circular(11 * s),
      ),
      child: Stack(
        children: <Widget>[
          Positioned(
            left: (25.7 - iconWidth / 2) * s,
            top: multiline ? (26.5 - iconHeight / 2) * s : 0,
            bottom: multiline ? null : 0,
            child: Center(
              child: AppAssetIcon(
                iconAsset,
                width: iconWidth * s,
                height: iconHeight * s,
                color: AppColors.hint,
              ),
            ),
          ),
          Positioned(
            left: 48 * s,
            right: (suffix == null ? 16 : 52) * s,
            top: multiline ? 17.7 * s : 0,
            bottom: multiline ? 10 * s : 0,
            child: Center(
              child: TextField(
                maxLines: multiline ? null : 1,
                expands: multiline,
                textAlignVertical:
                    multiline ? TextAlignVertical.top : TextAlignVertical.center,
                controller: controller,
                obscureText: obscureText,
                keyboardType: keyboardType,
                textInputAction: textInputAction,
                autofillHints: autofillHints,
                onChanged: onChanged,
                onSubmitted: onSubmitted,
                autocorrect: false,
                enableSuggestions: !obscureText,
                cursorColor: AppColors.accent,
                style: AppTextStyles.fieldText.scaled(s),
                decoration: InputDecoration(
                  isCollapsed: true,
                  border: InputBorder.none,
                  hintText: hint,
                  hintStyle: AppTextStyles.fieldHint.scaled(s),
                ),
              ),
            ),
          ),
          if (suffix != null)
            Positioned(
              right: 0,
              top: 0,
              bottom: 0,
              width: 52 * s,
              child: suffix!,
            ),
        ],
      ),
    );
  }
}
