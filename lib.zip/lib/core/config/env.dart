/// Environment values. Override at build time without touching code:
///
///   flutter run --dart-define=API_BASE_URL=https://api.example.com/api
abstract final class Env {
  static const String baseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'http://192.168.0.170/eCoachPro-Backend/api',
  );

  static const Duration connectTimeout = Duration(seconds: 30);
  static const Duration receiveTimeout = Duration(seconds: 30);
}
